# Growth-to-Give: The Giving Workbook

Proof of concept of the Giving section of the Growth-to-Give framework
(Ascension Analytics Consulting).

A static site: `index.html` plus the `images` folder. No build step.
Participants' answers are saved only in their own browser.
